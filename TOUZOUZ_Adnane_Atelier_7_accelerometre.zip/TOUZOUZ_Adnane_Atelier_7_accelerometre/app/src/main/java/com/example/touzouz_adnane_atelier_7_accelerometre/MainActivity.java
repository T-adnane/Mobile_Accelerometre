package com.example.touzouz_adnane_atelier_7_accelerometre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Pair;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.List;
public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private TextView activityText;
    private TableLayout activityTable;

    int highestIndex = 0;
    float highestConfidence = 0;

    private int currentActivity = -1;
    private int[] activityCounters = new int[4];
    private int[] activityConfidences = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activityText = findViewById(R.id.activity_text);
        activityTable = findViewById(R.id.activity_table);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        int activity = -1;
        int confidence = 0;

        // Detect activity
        if (Math.abs(z) > 9.8f) {
            activity = 3;
        } else if (Math.abs(y) > 9.8f) {
            activity = 2;
        } else if (Math.abs(x) > 9.8f) {
            activity = 1;
        } else {
            activity = 0;
        }

        // Update counters and confidences
        if (activity != currentActivity) {
            currentActivity = activity;
            activityCounters[activity]++;
            for (int i = 0; i < activityConfidences.length; i++) {
                activityConfidences[i] = (int) (100f * activityCounters[i] / (float) (activityCounters[0] + activityCounters[1] + activityCounters[2] + activityCounters[3]));
            }
        }

        // Display activity and confidence
        switch (activity) {
            case 0:
                activityText.setText("Assis");
                break;
            case 1:
                activityText.setText("Debout");
                break;
            case 2:
                activityText.setText("Marche");
                break;
            case 3:
                activityText.setText("Saut");
                break;
        }
        updateActivityTable();
    }

    private void updateActivityTable() {
        for (int i = 0; i < activityConfidences.length; i++) {
            TableRow row = (TableRow) activityTable.getChildAt(i + 1);
            TextView activityTextView = (TextView) row.getChildAt(0);
            TextView confidenceTextView = (TextView) row.getChildAt(1);

            switch (i) {
                case 0:
                    activityTextView.setText("Assis");
                    break;
                case 1:
                    activityTextView.setText("Debout");
                    break;
                case 2:
                    activityTextView.setText("Marche");
                    break;
                case 3:
                    activityTextView.setText("Saut");
                    break;
            }

            float confidence = activityConfidences[i];
            confidenceTextView.setText(confidence + "%");

            // Set background color to the highest confidence value
            if (confidence > highestConfidence) {
                highestIndex = i;
                highestConfidence = confidence;
            }

            if (i == highestIndex) {
                confidenceTextView.setBackgroundColor(Color.GREEN);
            } else {
                confidenceTextView.setBackgroundColor(Color.TRANSPARENT);
            }
        }
    }



    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}